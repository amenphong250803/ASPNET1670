﻿using ASM1670.Data;
using ASM1670.Models;
using Microsoft.AspNetCore.Mvc;

namespace ASM1670.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly ASM1670Context _context;

        public CheckoutController(ASM1670Context context)
        {
            _context = context;
        }

        public async Task<IActionResult> Checkout()
        {
            List<Cart> carts = HttpContext.Session.GetJson<List<Cart>>("Cart") ?? new List<Cart>();

            decimal grandTotal = carts.Sum(x => x.Quantity * x.Price);

            var ordercode = Guid.NewGuid().ToString();
            var orderItem = new Order()
            {
                OrderCode = ordercode,
                Status = 1,
                CreatedDate = DateTime.Now,
                TotalAmount = grandTotal
            };

            _context.Add(orderItem);
            await _context.SaveChangesAsync(); 

            TempData["Success"] = "Success";

            HttpContext.Session.Remove("Cart");

            return RedirectToAction("Index", "Home");
        }
    }
}