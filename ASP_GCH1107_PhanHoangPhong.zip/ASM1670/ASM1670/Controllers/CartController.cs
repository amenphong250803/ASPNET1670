﻿using ASM1670.Data;
using ASM1670.Models;
using ASM1670.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace ASM1670.Controllers
{
	public class CartController : Controller
	{
		private readonly ASM1670Context _context;
		public CartController(ASM1670Context context)
		{
			_context = context;
		}	
		public IActionResult Index()
		{
			List<Cart> carts = HttpContext.Session.GetJson<List<Cart>>("Cart") ?? new List<Cart>();
			CartItem cartVM = new()
			{
				CartItems = carts,
				GrandTotal = carts.Sum(x => x.Quantity * x.Price),
			};
			return View(cartVM);
		}

		public async Task<IActionResult> Add(int Id)
		{
			Product product = await _context.Product.FindAsync(Id);
			List<Cart> cartP = HttpContext.Session.GetJson<List<Cart>>("Cart") ?? new List<Cart>();
			Cart carts = cartP.Where(c => c.ProductId == Id).FirstOrDefault();
			if(carts == null)
			{
				cartP.Add(new Cart(product));
			}
			else
			{
				carts.Quantity += 1;
			}
			HttpContext.Session.SetJson("Cart", cartP);
			return Redirect(Request.Headers["Referer"].ToString());
		}

		public async Task<IActionResult> Remove(int Id)
		{
			List<Cart> cartP = HttpContext.Session.GetJson<List<Cart>>("Cart");

			cartP.RemoveAll(c => c.ProductId == Id);

			if(cartP.Count == 0)
			{
				HttpContext.Session.Remove("Cart");
			}
			else
			{
				HttpContext.Session.SetJson("Cart", cartP);
			}
			return RedirectToAction("Index");
		}

		public async Task<IActionResult> Decrease(int Id)
		{
			List<Cart> cartP = HttpContext.Session.GetJson<List<Cart>>("Cart");
			Cart carts =cartP.Where(c => c.ProductId == Id).FirstOrDefault();
			if (carts.Quantity > 1)
			{
				--carts.Quantity;
			}
			else
			{
				cartP.RemoveAll(p => p.ProductId == Id);
			}
			if (cartP.Count == 0)
			{
				HttpContext.Session.Remove("Cart");
			}
			else
			{
				HttpContext.Session.SetJson("Cart", cartP);
			}
			return RedirectToAction("Index");
		}

        public async Task<IActionResult> Increase(int Id)
        {
            List<Cart> cartP = HttpContext.Session.GetJson<List<Cart>>("Cart");
            Cart carts = cartP.Where(c => c.ProductId == Id).FirstOrDefault();
            if (carts.Quantity >= 1)
            {
                ++carts.Quantity;
            }
            else
            {
                cartP.RemoveAll(p => p.ProductId == Id);
            }
            if (cartP.Count == 0)
            {
                HttpContext.Session.Remove("Cart");
            }
            else
            {
                HttpContext.Session.SetJson("Cart", cartP);
            }
            return RedirectToAction("Index");
        }
    }
}
