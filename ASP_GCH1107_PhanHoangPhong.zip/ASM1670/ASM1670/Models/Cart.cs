﻿namespace ASM1670.Models
{
	public class Cart
	{
		public long ProductId { get; set; }
		public string ProductName { get; set; }

		public int Quantity { get; set; }
		public decimal Price { get; set; }
		public decimal Total { get { return Quantity * Price; } }

		public string ImageUrl { get; set; }
		public Cart()
		{

		}

		public Cart(Product product)
		{
			ProductId = product.Id;
			ProductName = product.Name;
			Price = product.Price;
			Quantity = 1;
			ImageUrl = product.ImageUrl;
		}
	}
}
