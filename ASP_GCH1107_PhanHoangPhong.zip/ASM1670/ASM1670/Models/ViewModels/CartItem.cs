﻿namespace ASM1670.Models.ViewModels
{
	public class CartItem
	{
		public List<Cart>? CartItems { get; set; }
		public decimal GrandTotal { get; set; }
	}
}
