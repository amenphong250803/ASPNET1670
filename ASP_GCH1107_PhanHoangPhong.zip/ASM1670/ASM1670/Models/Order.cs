﻿namespace ASM1670.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string OrderCode { get; set; }
        public DateTime CreatedDate { get; set; }
        public int Status { get; set; }
        public decimal TotalAmount { get; set; }

    }
}
