﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ASM1670.Models;
using ASM1670.Models.ViewModels;

namespace ASM1670.Data
{
    public class ASM1670Context : DbContext
    {
        public ASM1670Context (DbContextOptions<ASM1670Context> options)
            : base(options)
        {
        }

        public DbSet<ASM1670.Models.Category> Category { get; set; } = default!;

        public DbSet<ASM1670.Models.Product> Product { get; set; } = default!;
        public DbSet<ASM1670.Models.Order> Order { get; set; } = default!;
    }
}
